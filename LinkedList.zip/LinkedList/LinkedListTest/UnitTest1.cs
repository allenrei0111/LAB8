﻿using lab8;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace LinkedListTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestAddFirst()
        {
            LinkedList list = new LinkedList();
            list.AddFirst("Joe Blow");
            list.AddFirst("Joe Schmoe");
            Assert.AreEqual("Joe Schmoe", list.GetValue(0));
            Assert.AreEqual("Joe Blow", list.GetValue(1));
            Assert.AreEqual(2, list.Count);
        }

        [TestMethod]
        public void TestAddLast()
        {
            LinkedList list = new LinkedList();
            list.AddLast("John Smith");
            list.AddLast("Jane Doe");
            Assert.AreEqual("John Smith", list.GetValue(0));
            Assert.AreEqual("Jane Doe", list.GetValue(1));
            Assert.AreEqual(2, list.Count);
        }
    }
}

