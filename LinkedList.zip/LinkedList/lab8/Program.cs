﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab8
{
    public class Program
    {
        public static void Main()
        {
            LinkedList list = new LinkedList();
            list.AddFirst("Joe Blow");
            list.AddLast("John Smith");
            Console.WriteLine("First value: " + list.GetValue(0)); // Output: First value: Joe Blow
            Console.WriteLine("Last value: " + list.GetValue(1)); // Output: Last value: John Smith
            list.RemoveFirst();
            Console.WriteLine("First value after removing first node: " + list.GetValue(0)); // Output: First value after removing first node: John Smith
            list.RemoveLast();
            Console.WriteLine("List count after removing last node: " + list.Count); // Output: List count after removing last node: 0
        }
    }
}
